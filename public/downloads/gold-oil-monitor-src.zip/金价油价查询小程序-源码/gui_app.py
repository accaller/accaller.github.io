# -*- coding: utf-8 -*-
"""
=============================================================
 金价 / 油价 / 汇率 实时查询工具 (GUI版)  v2.0
 ------------------------------------------------------------
 功能说明：
   1. 文字区显示全部数据（金交所各品种 + 油价 + 汇率）
   2. 趋势图只画 Au99.99、92#、95# 三条线（精确到分钟）
   3. 默认省份：湖北；支持下拉切换
   4. 每天自动刷新一次 + 手动即时刷新
   5. 历史数据用 pandas 存 CSV，异常弹窗友好提示
 结构说明：
   [配置区] -> [请求工具] -> [历史记录器] -> [GUI 应用] -> [入口]
=============================================================
"""
import tkinter as tk
from tkinter import ttk, messagebox
import datetime
import json
import os
import requests
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import font_manager

# ============================================================
# 一、配置区
# ============================================================
CONFIG_FILE = "config.json"
HISTORY_CSV = "price_history.csv"

# 趋势图只追踪这三个品种
TREND_ITEMS = ["Au99.99", "92#汽油", "95#汽油"]

# 让 matplotlib 中文不乱码
for f in font_manager.fontManager.ttflist:
    if any(k in f.name for k in ("YaHei", "SimHei", "Microsoft YaHei")):
        plt.rcParams["font.sans-serif"] = [f.name]
        break
plt.rcParams["axes.unicode_minus"] = False


def load_config():
    """从 config.json 读取三个 API Key；文件不存在则创建默认"""
    default = {
        "GOLD_API_KEY": "",
        "OIL_API_KEY": "",
        "EXCHANGE_API_KEY": ""
    }
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        for k in default:
            data.setdefault(k, "")
        return data
    except Exception:
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(default, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return default


CFG = load_config()
GOLD_API_KEY = CFG.get("GOLD_API_KEY", "")
OIL_API_KEY = CFG.get("OIL_API_KEY", "")
EXCHANGE_API_KEY = CFG.get("EXCHANGE_API_KEY", "")

API_HEADERS = {"Referer": "https://www.juhe.cn/"}


# ============================================================
# 二、网络请求工具
# ============================================================
def get_json(url, key):
    """通用 GET + JSON 解析，失败返回 None"""
    if not key:
        return None
    try:
        resp = requests.get(url, params={"key": key},
                            headers=API_HEADERS, timeout=10)
        return resp.json()
    except Exception:
        return None


# ============================================================
# 三、历史数据记录器
# ============================================================
class HistoryRecorder:
    """把目标品种追加到 CSV，同一天同价去重防止重复堆积"""

    def __init__(self):
        self._dedup = {}

    def record(self, item, price):
        if price is None:
            return
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        today = now[:10]
        key = (item, today)
        if self._dedup.get(key) == price:
            return          # 今天同价已记过
        self._dedup[key] = price
        try:
            row = pd.DataFrame([{"time": now, "item": item,
                                 "price": float(price)}])
            if os.path.exists(HISTORY_CSV):
                row.to_csv(HISTORY_CSV, mode="a", header=False,
                           index=False, encoding="utf-8")
            else:
                row.to_csv(HISTORY_CSV, index=False, encoding="utf-8")
        except Exception:
            pass


# ============================================================
# 四、GUI 应用
# ============================================================
class App:
    def __init__(self, root):
        self.root = root
        root.title("金价 / 油价 / 汇率 实时查询 (默认湖北)")
        root.geometry("680x560")
        self.recorder = HistoryRecorder()

        # ---- 顶部工具栏：省份 + 刷新按钮 ----
        top = ttk.Frame(root, padding=8)
        top.pack(fill="x")
        ttk.Label(top, text="省份: ").pack(side="left")
        self.city_var = tk.StringVar(value="湖北")
        self.city_combo = ttk.Combobox(top, textvariable=self.city_var,
                                       state="readonly", width=8)
        self.city_combo.pack(side="left", padx=4)
        ttk.Button(top, text="立即刷新",
                   command=self.manual_refresh).pack(side="left", padx=12)

        # ---- 结果显示区 ----
        self.result_box = tk.Text(root, height=13, width=82,
                                  font=("Consolas", 10))
        self.result_box.pack(padx=10, pady=5, fill="both", expand=True)
        self.result_box.tag_config("up", foreground="red")
        self.result_box.tag_config("down", foreground="green")

        # ---- 底部：趋势图按钮 ----
        bottom = ttk.Frame(root, padding=8)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="查看趋势图 (Au/92#/95#)",
                   command=self.show_trend).pack(side="left")
        tk.Label(bottom, text="趋势图仅含 Au99.99 / 92# / 95#",
                 fg="gray").pack(side="left", padx=10)

        self.load_provinces()
        self._last_day = None
        self.after_daily_check()

    # ---------- 加载省份下拉 ----------
    def load_provinces(self):
        data = get_json("https://apis.juhe.cn/gnyj/query", OIL_API_KEY)
        cities = []
        if data and data.get("reason") == "success!":
            cities = [i["city"] for i in data["result"]]
        self.provinces = cities or ["广东", "北京", "湖北", "上海"]
        self.city_combo["values"] = self.provinces
        if "湖北" in self.provinces:
            self.city_var.set("湖北")
        elif self.provinces:
            self.city_var.set(self.provinces[0])

    # ---------- 每天自动刷新 ----------
    def after_daily_check(self):
        today = datetime.date.today().isoformat()
        if self._last_day != today:
            self._last_day = today
            self.do_query(notify_error=True)
        self.root.after(60_000, self.after_daily_check)

    # ---------- 手动刷新 ----------
    def manual_refresh(self):
        self.do_query(notify_error=False)

    # ============ 数据抓取 ============
    def _show_line(self, label, value, change=None):
        """向文本框写一行，涨跌幅上色"""
        line = f"  {label:<24}{value:>14}"
        self.result_box.insert("end", line)
        if change:
            try:
                c = float(str(change).replace("%", ""))
            except Exception:
                c = 0
            tag = "up" if c > 0 else ("down" if c < 0 else None)
            self.result_box.insert("end", f"{change:>9}",
                                   tag if tag else None)
        else:
            self.result_box.insert("end", " " * 9)
        self.result_box.insert("end", "\n")

    def fetch_gold(self):
        """金交所各品种，显示全部，只记录 Au99.99"""
        data = get_json("https://web.juhe.cn/finance/gold/shgold",
                        GOLD_API_KEY)
        if not data:
            return False, "连接金价接口失败"
        if data.get("error_code", 0) != 0:
            return False, "金价:" + str(data.get("reason", "错误"))

        au99 = None
        items = data["result"][0]
        for v in items.values():
            if not isinstance(v, dict):
                continue
            variety, latest = v.get("variety"), v.get("latestpri")
            if latest in (None, "--"):
                continue
            price = float(latest)
            group = ("金" if variety.startswith("Au") or variety.startswith("AU")
                     else "银" if variety.startswith("Ag") else "其他")
            unit = "元/千克" if group == "银" else "元/克"
            self._show_line(f"{group} {variety} ({unit})",
                            f"{price:,.2f}", v.get("limit"))
            if variety == "Au99.99":
                au99 = price
        if au99 is not None:
            self.recorder.record("Au99.99", au99)
        return True, ""

    def fetch_oil(self, city):
        """显示该省 92/95/98/0号，只记录 92#、95#"""
        data = get_json("https://apis.juhe.cn/gnyj/query", OIL_API_KEY)
        if not data:
            return False, "连接油价接口失败"
        if data.get("reason") != "success!":
            return False, "油价:" + str(data.get("reason", "错误"))
        t = next((i for i in data["result"] if i.get("city") == city), None)
        if not t:
            return False, f"未找到城市 {city}"
        for code, name in (("92h", "92#"), ("95h", "95#"),
                           ("98h", "98#"), ("0h", "0#")):
            self._show_line(f"{name}汽油 {city} (元/升)", t[code])
        self.recorder.record("92#汽油", float(t["92h"]))
        self.recorder.record("95#汽油", float(t["95h"]))
        return True, ""

    def fetch_exchange(self):
        """显示美元汇率，不记录"""
        data = get_json("https://web.juhe.cn/finance/exchange/rmbquot",
                        EXCHANGE_API_KEY)
        if not data:
            return False, "连接汇率接口失败"
        if data.get("error_code", 0) != 0:
            return False, "汇率:" + str(data.get("reason", "错误"))
        for v in data["result"][0].values():
            if isinstance(v, dict) and v.get("name") == "美元":
                conv = float(v["bankConversionPri"]) / 100.0
                self._show_line("汇率 美元兑人民币", f"{conv:.4f}")
                return True, ""
        return False, "未找到美元汇率"

    # ============ 主查询 ============
    def do_query(self, notify_error=False):
        self.result_box.delete("1.0", "end")
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.result_box.insert("end", "=" * 66 + "\n")
        self.result_box.insert("end",
            f" 查询时间: {now}    省份: {self.city_var.get()}\n")
        self.result_box.insert("end", "-" * 66 + "\n")

        errors = []
        for ok, msg in (self.fetch_gold(),
                        self.fetch_oil(self.city_var.get()),
                        self.fetch_exchange()):
            if not ok:
                errors.append(msg)

        if errors:
            if notify_error:
                messagebox.showwarning("部分数据获取失败", "\n".join(errors))
            else:
                self.result_box.insert("end", "\n[失败] " + "\n".join(errors))
        else:
            self.result_box.insert("end", "\n(已保存 Au99.99/92#/95# 历史)")

    # ============ 趋势图 ============
    def show_trend(self):
        if not os.path.exists(HISTORY_CSV):
            messagebox.showinfo("提示", "暂无历史数据，请先刷新几次。")
            return
        try:
            df = pd.read_csv(HISTORY_CSV, encoding="utf-8")
            df["time"] = pd.to_datetime(df["time"], errors="coerce")
            df = df.dropna(subset=["time"])
            df["time"] = df["time"].dt.floor("min")   # 精确到分钟
            df = df.sort_values("time")

            df = df[df["item"].isin(TREND_ITEMS)]
            if df.empty:
                messagebox.showinfo("提示", "暂无 Au99.99/92#/95# 数据")
                return

            items = [i for i in TREND_ITEMS if i in df["item"].unique()]
            n = len(items)
            fig, axes = plt.subplots(n, 1, figsize=(9, 3.2 * n),
                                     sharex=True)
            if n == 1:
                axes = [axes]

            for ax, it in zip(axes, items):
                sub = df[df["item"] == it]
                ax.plot(sub["time"], sub["price"], marker="o",
                        markersize=4, linewidth=1.8)
                ax.set_ylabel(it, fontsize=9)
                ax.legend([it], loc="upper left", fontsize=8)
                ax.grid(True, alpha=0.3)

            axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
            axes[-1].set_xlabel("时间 (时:分)")
            fig.suptitle("Au99.99 黄金 / 92# / 95# 汽油 价格趋势")
            fig.autofmt_xdate()
            fig.tight_layout()
            plt.show()
        except Exception as e:
            messagebox.showerror("画图失败", str(e))


# ============================================================
# 五、程序入口
# ============================================================
if __name__ == "__main__":
    root = tk.Tk()
    # 加载窗口图标（.ico 与 exe 放在同一目录）
    ICON_FILE = "coin_oil.ico"
    if os.path.exists(ICON_FILE):
        try:
            root.iconbitmap(ICON_FILE)
        except Exception:
            pass
    App(root)
    root.mainloop()