# 金价油价查询小程序 · 源码

一个用 Python + tkinter 写的桌面小工具：查询国际金价与国内成品油价，带简单图形界面。

## 文件说明

| 文件 | 作用 |
|------|------|
| `gui_app.py` | 图形界面主程序（入口），双击运行 |
| `monitor.py` | 数据抓取模块（金价 / 油价 / 汇率） |
| `config.json` | 三个 API Key 配置（见下方说明） |
| `requirements.txt` | 第三方依赖清单 |
| `coin_oil.ico` | 程序图标 |

## 运行环境

- Windows / macOS / Linux（带图形界面的系统）
- Python 3.9+（建议 3.10+）

## 快速开始

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 运行（在项目目录下）
python gui_app.py
```

## 关于 API Key（重要）

本源码包中的 `config.json` 与 `monitor.py` 里的 API Key 已替换为占位符 `YOUR_API_KEY`，
**不包含真实密钥**。

数据来自「聚合数据」(juhe.cn)。如需运行，请：

1. 前往 [聚合数据](https://www.juhe.cn/) 注册
2. 开通「国内油价」「上海黄金交易所金价」「人民币汇率」三个接口，获取三个 Key
3. 填入 `config.json`，并同步替换 `monitor.py` 里的占位符

> 提示：聚合数据的免费接口有每日调用次数限制，仅供个人学习使用。

## 打包为 exe（可选）

如需打成免安装的 Windows exe，可用 PyInstaller：

```bash
pip install pyinstaller
pyinstaller -F -w --icon=coin_oil.ico --add-data "coin_oil.ico;." gui_app.py
```

或直接使用项目内的 `金价油价查询.spec` 配置（用 `pyinstaller 金价油价查询.spec`）。
