# -*- coding: utf-8 -*-
"""
金价 + 油价 + 汇率 三合一查询工具
数据源：聚合数据
"""
import requests

# ==================== 配置区域 ====================
OIL_API_KEY = "YOUR_API_KEY"        # 油价 Key
GOLD_API_KEY = "YOUR_API_KEY"       # 金价 Key
EXCHANGE_API_KEY = "YOUR_API_KEY"   # 汇率 Key
TARGET_CITY = "湖北"   # 你要看的省份
# =================================================

def get_data(url, key, extra_params=None):
    """通用请求函数"""
    headers = {"Referer": "https://www.juhe.cn/"}
    params = {"key": key}
    if extra_params:
        params.update(extra_params)
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=10)
        return resp.json()
    except Exception:
        print("请求失败，请检查网络")
        return None


def fetch_gold():
    """上海金交所黄金/白银价格"""
    print("\n" + "=" * 52)
    print("【上海金交所 黄金/白银】（人民币报价）")
    print("=" * 52)
    data = get_data("https://web.juhe.cn/finance/gold/shgold", GOLD_API_KEY)
    if not data or data.get("error_code", 0) != 0:
        print("金价接口错误：", data.get("reason", "未知") if data else "无返回")
        return
    items = data["result"][0]
    for key in items:
        item = items[key]
        variety = item.get("variety")
        latest = item.get("latestpri")
        if latest == "--":
            continue
        if variety in ("Au99.99", "Au(T+D)", "Au100g"):
            print(f"  {variety:<9}  {float(latest):>9.2f} 元/克   "
                  f"涨跌 {item.get('limit','--')}")
        elif variety == "Ag(T+D)":
            print(f"  {variety:<9}  {float(latest):>9.2f} 元/千克  "
                  f"涨跌 {item.get('limit','--')}")
    time_str = items.get("1", {}).get("time", "")
    if time_str:
        print("  数据时间:", time_str)


def fetch_oil():
    """指定省份油价"""
    print("\n" + "=" * 52)
    print(f"【油价】省份：{TARGET_CITY}（元/升）")
    print("=" * 52)
    data = get_data("https://apis.juhe.cn/gnyj/query", OIL_API_KEY)
    if not data or data.get("reason") != "success!":
        print("油价接口错误：", data.get("reason", "未知") if data else "无返回")
        return
    result = data["result"]
    target = None
    for item in result:
        if item.get("city") == TARGET_CITY:
            target = item
            break
    if target:
        print(f"  92号汽油: {target['92h']} 元/升")
        print(f"  95号汽油: {target['95h']} 元/升")
        print(f"  98号汽油: {target['98h']} 元/升")
        print(f"  0号柴油:  {target['0h']} 元/升")
    else:
        print(f"  未找到 '{TARGET_CITY}'，可用省份：")
        print("  ", "、".join([i["city"] for i in result]))


def fetch_exchange():
    """美元兑人民币汇率 + 美元金价换算演示"""
    print("\n" + "=" * 52)
    print("【汇率】美元兑人民币")
    print("=" * 52)
    data = get_data("https://web.juhe.cn/finance/exchange/rmbquot", EXCHANGE_API_KEY)
    if not data or data.get("error_code", 0) != 0:
        print("汇率接口错误：", data.get("reason", "未知") if data else "无返回")
        return None

    # 找到名为"美元"的那一条
    usd = None
    for v in data["result"][0].values():  # 便利 data1, data2...
        if isinstance(v, dict) and v.get("name") == "美元":
            usd = v
            break

    if not usd:
        print("未找到美元汇率")
        return None

    # 银行的"折算价"，注意这里每100外币 = 折算价 元 人民币
    cny_per_100usd = float(usd["bankConversionPri"])
    usd_cny = cny_per_100usd / 100.0   # 得到 1美元 = ? 元人民币

    # 打印关键汇率
    print(f"  卖出价: {float(usd['mSellPri'])/100:.4f} 元/美元")
    print(f"  折算价: {usd_cny:.4f} 元/美元")
    print(f"  数据时间: {usd['date']} {usd['time']}")

    # ---------- 演示：把"美元/盎司"的国际金价 换算成"元/克" ----------
    print("\n  【换算演示】假设此刻伦敦金 = 2000 美元/盎司：")
    ounce_gram = 31.1035   # 1金衡盎司 = 31.1035克
    usd_per_ounce = 2000.0
    cny_per_gram = usd_per_ounce * usd_cny / ounce_gram
    print(f"  2000 美元/盎司 × {usd_cny:.4f} ÷ 31.1035 = "
          f"{cny_per_gram:.2f} 元/克")

    # ---------- 和国内金交所价格对比 ----------
    print(f"\n  对比：上海金交所 Au99.99 约 958 元/克")
    print(f"  说明：国际价(美元)换算出的人民币价若接近国内价，则汇率和行情一致。")
    return usd_cny


if __name__ == "__main__":
    fetch_gold()
    fetch_oil()
    fetch_exchange()
    print("\n查询完成。")